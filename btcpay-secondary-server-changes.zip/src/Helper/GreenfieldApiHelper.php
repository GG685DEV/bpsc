<?php

declare(strict_types=1);

namespace BTCPayServer\WC\Helper;

use BTCPayServer\Client\ApiKey;
use BTCPayServer\Client\Invoice;
use BTCPayServer\Client\Server;
use BTCPayServer\Client\Store;
use BTCPayServer\Client\StorePaymentMethod;
use BTCPayServer\Client\Webhook;
use BTCPayServer\Result\AbstractStorePaymentMethodResult;
use BTCPayServer\Result\ServerInfo;
use BTCPayServer\WC\Admin\Notice;

class GreenfieldApiHelper {
	const PM_CACHE_KEY = 'btcpay_payment_methods';
	const PM_CLASS_NAME_PREFIX = 'BTCPay_GF_';

	// Identifiers for the two configurable BTCPay Server connections.
	const SERVER_PRIMARY = 'primary';
	const SERVER_SECONDARY = 'secondary';

	// Orders with a total greater than this (in store currency) are routed to the secondary server.
	const SECONDARY_ORDER_TOTAL_THRESHOLD = 200;

	// Users with this role may only pay through the secondary server.
	const BLACKLISTED_ROLE = 'blacklisted';

	public $configured = false;
	public $server;
	public $url;
	public $apiKey;
	public $storeId;
	public $webhook;

	// todo: need to refactor as it loads cached options if form submitted by ajax
	public function __construct(string $server = self::SERVER_PRIMARY) {
		$this->server = $server;
		if ($config = self::getConfig($server)) {
			$this->url = $config['url'];
			$this->apiKey = $config['api_key'];
			$this->storeId = $config['store_id'];
			$this->webhook = $config['webhook'];
			$this->configured = true;
		}
	}

	/**
	 * Returns the option name for a given base key and server. The secondary server uses
	 * the same option names as the primary one, suffixed with "_secondary".
	 */
	public static function optionName(string $base, string $server = self::SERVER_PRIMARY): string {
		return $server === self::SERVER_SECONDARY ? $base . '_secondary' : $base;
	}

	// todo: maybe remove static class and make GFConfig object or similar
	public static function getConfig(string $server = self::SERVER_PRIMARY): array {
		// todo: perf: maybe add caching
		$url = get_option(self::optionName('btcpay_gf_url', $server));
		$key = get_option(self::optionName('btcpay_gf_api_key', $server));
		if ($url && $key) {
			return [
				'url' => rtrim($url, '/'),
				'api_key' => $key,
				'store_id' => get_option(self::optionName('btcpay_gf_store_id', $server), null),
				'webhook' => get_option(self::optionName('btcpay_gf_webhook', $server), null)
			];
		}
		else {
			return [];
		}
	}

	/**
	 * Checks if the customer of an order has the blacklisted role. Guests can never be blacklisted.
	 */
	public static function orderUserIsBlacklisted(\WC_Order $order): bool {
		$userId = $order->get_user_id();
		if (!$userId) {
			return false;
		}

		$user = get_user_by('id', $userId);
		if (!$user instanceof \WP_User) {
			return false;
		}

		return in_array(self::BLACKLISTED_ROLE, (array) $user->roles, true);
	}

	/**
	 * Determines which BTCPay Server an order should be routed to based on the configured rules:
	 * - Blacklisted users may only use the secondary server.
	 * - Orders with a total above the threshold use the secondary server too.
	 * - Everything else uses the primary server.
	 */
	public static function computeServerForOrder(\WC_Order $order): string {
		if (self::orderUserIsBlacklisted($order)) {
			return self::SERVER_SECONDARY;
		}

		if ((float) $order->get_total() > self::SECONDARY_ORDER_TOTAL_THRESHOLD) {
			return self::SERVER_SECONDARY;
		}

		return self::SERVER_PRIMARY;
	}

	/**
	 * Resolves the server for an order. Once an invoice has been created the stored choice wins so
	 * later webhook processing keeps talking to the same server the invoice lives on.
	 */
	public static function getServerForOrder(\WC_Order $order): string {
		$stored = $order->get_meta('BTCPay_server');
		if (in_array($stored, [self::SERVER_PRIMARY, self::SERVER_SECONDARY], true)) {
			return $stored;
		}

		return self::computeServerForOrder($order);
	}

	/**
	 * Builds the API helper for the server an order should use. Falls back to the primary server if
	 * the order should use the secondary one but it is not configured (so checkout never breaks).
	 */
	public static function forOrder(\WC_Order $order): self {
		return self::forServer(self::getServerForOrder($order), 'Order #' . $order->get_id());
	}

	/**
	 * Best-effort server resolution before an order exists (e.g. the modal checkout script needs to
	 * load BTCPay's modal from the right server). Based on the current user role and the cart total.
	 */
	public static function forCart(): self {
		$server = self::SERVER_PRIMARY;

		$user = function_exists('wp_get_current_user') ? wp_get_current_user() : null;
		if ($user && $user->ID && in_array(self::BLACKLISTED_ROLE, (array) $user->roles, true)) {
			$server = self::SERVER_SECONDARY;
		} elseif (function_exists('WC') && WC()->cart && (float) WC()->cart->get_total('edit') > self::SECONDARY_ORDER_TOTAL_THRESHOLD) {
			$server = self::SERVER_SECONDARY;
		}

		return self::forServer($server, 'Cart');
	}

	/**
	 * Returns a configured helper for the requested server, falling back to the primary server when
	 * the secondary one is requested but not configured.
	 */
	private static function forServer(string $server, string $context): self {
		if ($server === self::SERVER_SECONDARY) {
			$helper = new self(self::SERVER_SECONDARY);
			if ($helper->configured) {
				return $helper;
			}
			Logger::debug($context . ' should use the secondary BTCPay Server but it is not configured, falling back to primary.');
		}

		return new self(self::SERVER_PRIMARY);
	}

	public static function checkApiKeyWorks(?string $url = null, ?string $apiKey = null): bool {
		$config = [];

		if ($url && $apiKey) {
			$config['url'] = $url;
			$config['api_key'] = $apiKey;
		} else {
			$config = self::getConfig();
		}

		if ($config) {
			$client = new Store($config['url'], $config['api_key']);
			if (!empty($client->getStores())) {
				return true;
			} else {
				Logger::debug('Could not fetch stores from BTCPay Server with the given API key.');
				return false;
			}
		}

		return false;
	}

	public static function getServerInfo(string $server = self::SERVER_PRIMARY): ?ServerInfo {
		if ($config = self::getConfig($server)) {
			try {
				$client = new Server( $config['url'], $config['api_key'] );
				return $client->getInfo();
			} catch (\Throwable $e) {
				Logger::debug('Error fetching server info: ' . $e->getMessage(), true);
				return null;
			}
		}

		return null;
	}

	/**
	 * List supported payment methods by BTCPay Server.
	 */
	public static function supportedPaymentMethods(): array {
		$paymentMethods = [];

		// Use transients API to cache pm for a few minutes to avoid too many requests to BTCPay Server.
		if ($cachedPaymentMethods = get_transient(self::PM_CACHE_KEY)) {
			return $cachedPaymentMethods;
		}

		if ($config = self::getConfig()) {
			$client = new StorePaymentMethod($config['url'], $config['api_key']);
			if ($storeId = get_option('btcpay_gf_store_id')) {
				try {
					$pmResult = $client->getPaymentMethods($storeId);
					/** @var AbstractStorePaymentMethodResult $pm */
					foreach ($pmResult as $pm) {
						if ($pm->isEnabled() && $pmName = $pm->getData()['paymentMethod'] )  {
							// Convert - to _ and escape value for later use in gateway class generator.
							$symbol = sanitize_html_class(str_replace('-', '_', $pmName));
							$paymentMethods[] = [
								'symbol' => $symbol,
								'className' => self::PM_CLASS_NAME_PREFIX . $symbol
							];
						}
					}
				} catch (\Throwable $e) {
					$exceptionPM = 'Exception loading payment methods: ' . $e->getMessage();
					Logger::debug( $exceptionPM, true);
					Notice::addNotice('error', $exceptionPM);
				}
			}
		}

		// Store payment methods into cache.
		set_transient( self::PM_CACHE_KEY, $paymentMethods,5 * MINUTE_IN_SECONDS );

		return $paymentMethods;
	}

	/**
	 * Deletes local cache of supported payment methods.
	 */
	public static function clearSupportedPaymentMethodsCache(): void {
		delete_transient( self::PM_CACHE_KEY );
	}

	/**
	 * Returns BTCPay Server invoice url.
	 */
	public function getInvoiceRedirectUrl($invoiceId): ?string {
		if ($this->configured) {
			return $this->url . '/i/' . urlencode($invoiceId);
		}
		return null;
	}

	/**
	 * Check webhook signature to be a valid request.
	 */
	public function validWebhookRequest(string $signature, string $requestData): bool {
		if ($this->configured) {
			return Webhook::isIncomingWebhookRequestValid($requestData, $signature, $this->webhook['secret']);
		}
		return false;
	}

	/**
	 * Checks if the provided API config already exists in options table.
	 */
	public static function apiCredentialsExist(string $apiUrl, string $apiKey, string $storeId): bool {
		if ($config = self::getConfig()) {
			if (
				$config['url'] === $apiUrl &&
				$config['api_key'] === $apiKey &&
				$config['store_id'] === $storeId
			) {
				return true;
			}
		}

		return false;
	}

	public static function webhookIsSetup(string $server = self::SERVER_PRIMARY): bool {
		if ($config = self::getConfig($server)) {
			return !empty($config['webhook']['secret']);
		}

		return false;
	}

	public static function webhookIsSetupManual(string $server = self::SERVER_PRIMARY): bool {
		if ($config = self::getConfig($server)) {
			return !empty($config['webhook']['secret']) && $config['webhook']['id'] === 'manual';
		}

		return false;
	}



	/**
	 * Checks if a given invoice id has status of fully paid (settled) or paid late.
	 */
	public static function invoiceIsFullyPaid(string $invoiceId, string $server = self::SERVER_PRIMARY): bool {
		if ($config = self::getConfig($server)) {
			$client = new Invoice($config['url'], $config['api_key']);
			try {
				$invoice = $client->getInvoice($config['store_id'], $invoiceId);
				return $invoice->isSettled();
			} catch (\Throwable $e) {
				Logger::debug('Exception while checking if invoice settled '. $invoiceId . ': ' . $e->getMessage());
			}
		}

		return false;
	}

	public function apiKeyHasRefundPermission(): bool {
		if ($this->configured) {
			$client = new ApiKey($this->url, $this->apiKey);
			try {
				$apiKey = $client->getCurrent();
				$apiAuth = new GreenfieldApiAuthorization( $apiKey->getData() );
				return $apiAuth->hasRefundsPermission();
			} catch (\Throwable $e) {
				Logger::debug('Exception while checking current API key: ' . $e->getMessage());
			}
		}

		return false;
	}

	public function serverSupportsRefunds(): bool {
		if ($this->configured) {
			$client = new Server($this->url, $this->apiKey);
			try {
				$serverInfo = $client->getInfo();
				return !version_compare($serverInfo->getVersion(), '1.7.6', '<');
			} catch (\Throwable $e) {
				Logger::debug('Exception while checking current API key: ' . $e->getMessage());
			}
		}

		return false;
	}

}
